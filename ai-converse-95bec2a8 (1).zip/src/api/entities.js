import { base44 } from './base44Client';


export const Message = base44.entities.Message;

export const ChatSettings = base44.entities.ChatSettings;

export const SavedConversation = base44.entities.SavedConversation;

export const Business = base44.entities.Business;



// auth sdk:
export const User = base44.auth;