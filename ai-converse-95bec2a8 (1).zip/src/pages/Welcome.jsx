
import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Building2, Rocket, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Welcome() {
  const navigate = useNavigate();
  const [isSelecting, setIsSelecting] = useState(false);
  const [isCheckingRole, setIsCheckingRole] = useState(true);
  const [referralId, setReferralId] = useState(null);

  useEffect(() => {
    // Check for referral code in URL
    const urlParams = new URLSearchParams(window.location.search);
    const ref = urlParams.get('ref');
    if (ref) {
      setReferralId(ref);
    }
    
    checkUserRole();
  }, []);

  const checkUserRole = async () => {
    try {
      const user = await User.me();
      
      // Admins and internal users skip the welcome page
      if (user.role === 'admin' || user.role === 'internal') {
        await User.updateMyUserData({ onboarding_completed: true });
        navigate(createPageUrl('Chat'));
        return;
      }
    } catch (error) {
      console.error('Error checking user role:', error);
    } finally {
      setIsCheckingRole(false);
    }
  };

  const handleSelection = async (businessType) => {
    setIsSelecting(true);
    try {
      const updateData = {
        business_type: businessType,
        onboarding_completed: true
      };
      
      // If there's a referral ID, save it
      if (referralId) {
        updateData.referred_by = referralId;
      }
      
      await User.updateMyUserData(updateData);
      navigate(createPageUrl('Chat'));
    } catch (error) {
      console.error('Error saving selection:', error);
      setIsSelecting(false);
    }
  };

  if (isCheckingRole) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#c6c6c6]/20 to-white flex items-center justify-center p-4">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[#510069] flex items-center justify-center animate-pulse">
            <Rocket className="w-8 h-8 text-white" />
          </div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#c6c6c6]/20 to-white flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl w-full"
      >
        <div className="text-center mb-12">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="w-20 h-20 mx-auto mb-6 rounded-full bg-[#510069] flex items-center justify-center shadow-2xl"
          >
            <Rocket className="w-10 h-10 text-white" />
          </motion.div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Welcome to Where 2 Start?
          </h1>
          <p className="text-lg text-gray-600">
            Choose the option that best describes you
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card 
              className="p-8 hover:shadow-2xl transition-all duration-300 cursor-pointer border-2 border-transparent hover:border-[#510069] group"
              onClick={() => !isSelecting && handleSelection('has_business')}
            >
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-[#9ab292]/20 flex items-center justify-center group-hover:bg-[#9ab292]/30 transition-colors">
                  <Building2 className="w-8 h-8 text-[#9ab292]" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-3">
                  I Have a Business
                </h2>
                <p className="text-gray-600 mb-6">
                  Get help managing and growing your existing business
                </p>
                <Button 
                  className="w-full bg-[#510069] hover:bg-[#510069]/90"
                  disabled={isSelecting}
                >
                  Select <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card 
              className="p-8 hover:shadow-2xl transition-all duration-300 cursor-pointer border-2 border-transparent hover:border-[#510069] group"
              onClick={() => !isSelecting && handleSelection('wants_to_start')}
            >
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-[#510069]/20 flex items-center justify-center group-hover:bg-[#510069]/30 transition-colors">
                  <Rocket className="w-8 h-8 text-[#510069]" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-3">
                  I Want to Start a Business
                </h2>
                <p className="text-gray-600 mb-6">
                  Get guidance on launching your business from scratch
                </p>
                <Button 
                  className="w-full bg-[#510069] hover:bg-[#510069]/90"
                  disabled={isSelecting}
                >
                  Select <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </Card>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
