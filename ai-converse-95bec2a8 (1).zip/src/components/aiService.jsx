import { InvokeLLM } from '@/api/integrations';

/**
 * Central AI service for generating responses
 * 
 * To integrate Google AI later:
 * 1. Add your Google AI API key configuration here
 * 2. Update this function to call Google AI API instead of InvokeLLM
 * 3. The rest of the app will automatically use the new integration
 */
export async function getAiResponse({ prompt, systemPrompt, conversationHistory }) {
  // Build the full prompt with system instructions and conversation history
  let fullPrompt = systemPrompt || 'You are a helpful AI assistant.';
  
  if (conversationHistory && conversationHistory.length > 0) {
    fullPrompt += '\n\nConversation:\n' + conversationHistory
      .map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`)
      .join('\n');
  }
  
  fullPrompt += '\n\nAssistant:';
  
  // Currently using the default InvokeLLM integration
  // TODO: Replace with Google AI when API key is available
  const response = await InvokeLLM({
    prompt: fullPrompt
  });
  
  return response;
}

/**
 * Configuration placeholder for future Google AI integration
 * 
 * Example usage when ready:
 * export const AI_CONFIG = {
 *   provider: 'google', // or 'default'
 *   apiKey: 'YOUR_GOOGLE_AI_API_KEY',
 *   model: 'gemini-pro'
 * };
 */